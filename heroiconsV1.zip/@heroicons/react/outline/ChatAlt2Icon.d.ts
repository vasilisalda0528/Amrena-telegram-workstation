import * as React from 'react';
declare function ChatAlt2Icon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChatAlt2Icon;
