import * as React from 'react';
declare function ChartPieIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChartPieIcon;
