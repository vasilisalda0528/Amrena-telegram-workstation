import * as React from 'react';
declare function ArrowNarrowLeftIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowNarrowLeftIcon;
