import * as React from 'react';
declare function EmojiSadIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default EmojiSadIcon;
