import * as React from 'react';
declare function ArrowRightIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowRightIcon;
