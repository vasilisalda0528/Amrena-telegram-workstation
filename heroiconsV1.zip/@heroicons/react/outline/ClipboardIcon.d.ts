import * as React from 'react';
declare function ClipboardIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ClipboardIcon;
