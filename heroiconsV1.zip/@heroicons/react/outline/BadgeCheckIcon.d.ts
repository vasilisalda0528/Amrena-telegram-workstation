import * as React from 'react';
declare function BadgeCheckIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default BadgeCheckIcon;
