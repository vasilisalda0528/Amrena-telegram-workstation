import * as React from 'react';
declare function CubeTransparentIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CubeTransparentIcon;
