import * as React from 'react';
declare function DocumentAddIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default DocumentAddIcon;
