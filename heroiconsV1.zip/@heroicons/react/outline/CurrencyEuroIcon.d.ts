import * as React from 'react';
declare function CurrencyEuroIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CurrencyEuroIcon;
