import * as React from 'react';
declare function ArrowCircleDownIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowCircleDownIcon;
