import * as React from 'react';
declare function DotsHorizontalIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default DotsHorizontalIcon;
