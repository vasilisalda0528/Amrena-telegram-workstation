import * as React from 'react';
declare function DuplicateIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default DuplicateIcon;
