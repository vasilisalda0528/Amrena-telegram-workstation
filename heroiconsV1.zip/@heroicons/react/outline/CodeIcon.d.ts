import * as React from 'react';
declare function CodeIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CodeIcon;
