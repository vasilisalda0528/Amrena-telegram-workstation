import * as React from 'react';
declare function DesktopComputerIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default DesktopComputerIcon;
