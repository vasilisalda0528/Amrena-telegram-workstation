import * as React from 'react';
declare function BookOpenIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default BookOpenIcon;
