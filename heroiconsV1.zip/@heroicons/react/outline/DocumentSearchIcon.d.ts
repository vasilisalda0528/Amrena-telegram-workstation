import * as React from 'react';
declare function DocumentSearchIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default DocumentSearchIcon;
