import * as React from 'react';
declare function ArrowCircleLeftIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowCircleLeftIcon;
