import * as React from 'react';
declare function CurrencyYenIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CurrencyYenIcon;
