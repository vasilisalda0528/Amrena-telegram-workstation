import * as React from 'react';
declare function ChevronDoubleLeftIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChevronDoubleLeftIcon;
