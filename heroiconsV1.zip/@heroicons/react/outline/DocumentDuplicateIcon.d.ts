import * as React from 'react';
declare function DocumentDuplicateIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default DocumentDuplicateIcon;
