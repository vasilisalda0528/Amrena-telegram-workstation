import * as React from 'react';
declare function ClockIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ClockIcon;
