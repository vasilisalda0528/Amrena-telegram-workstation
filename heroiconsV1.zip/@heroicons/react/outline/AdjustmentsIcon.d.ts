import * as React from 'react';
declare function AdjustmentsIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default AdjustmentsIcon;
