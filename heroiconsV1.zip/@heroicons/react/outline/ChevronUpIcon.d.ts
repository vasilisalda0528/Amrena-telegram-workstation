import * as React from 'react';
declare function ChevronUpIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChevronUpIcon;
