import * as React from 'react';
declare function CloudUploadIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CloudUploadIcon;
