import * as React from 'react';
declare function DocumentRemoveIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default DocumentRemoveIcon;
