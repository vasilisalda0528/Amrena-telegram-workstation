import * as React from 'react';
declare function ArrowNarrowUpIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowNarrowUpIcon;
