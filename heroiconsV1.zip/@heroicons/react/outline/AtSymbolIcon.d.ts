import * as React from 'react';
declare function AtSymbolIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default AtSymbolIcon;
