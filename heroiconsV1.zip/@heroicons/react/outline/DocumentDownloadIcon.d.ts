import * as React from 'react';
declare function DocumentDownloadIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default DocumentDownloadIcon;
