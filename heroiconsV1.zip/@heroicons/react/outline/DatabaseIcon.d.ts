import * as React from 'react';
declare function DatabaseIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default DatabaseIcon;
