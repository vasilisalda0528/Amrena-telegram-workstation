import * as React from 'react';
declare function CakeIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CakeIcon;
