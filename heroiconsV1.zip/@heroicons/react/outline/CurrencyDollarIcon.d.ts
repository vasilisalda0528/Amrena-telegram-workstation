import * as React from 'react';
declare function CurrencyDollarIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CurrencyDollarIcon;
