import * as React from 'react';
declare function BeakerIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default BeakerIcon;
