import * as React from 'react';
declare function ArrowCircleUpIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowCircleUpIcon;
