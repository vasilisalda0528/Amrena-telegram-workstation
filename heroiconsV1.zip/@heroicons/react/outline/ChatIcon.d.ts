import * as React from 'react';
declare function ChatIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChatIcon;
