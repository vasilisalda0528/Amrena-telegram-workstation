import * as React from 'react';
declare function ArrowSmRightIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowSmRightIcon;
