import * as React from 'react';
declare function ArrowsExpandIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowsExpandIcon;
