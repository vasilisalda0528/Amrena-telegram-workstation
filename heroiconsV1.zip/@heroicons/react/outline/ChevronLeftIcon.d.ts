import * as React from 'react';
declare function ChevronLeftIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChevronLeftIcon;
