import * as React from 'react';
declare function ArrowLeftIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowLeftIcon;
