import * as React from 'react';
declare function BookmarkAltIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default BookmarkAltIcon;
