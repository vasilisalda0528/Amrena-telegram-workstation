import * as React from 'react';
declare function ArrowNarrowRightIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowNarrowRightIcon;
