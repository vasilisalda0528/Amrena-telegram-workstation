import * as React from 'react';
declare function CloudDownloadIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CloudDownloadIcon;
