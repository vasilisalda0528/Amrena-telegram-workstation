import * as React from 'react';
declare function ArrowSmLeftIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowSmLeftIcon;
