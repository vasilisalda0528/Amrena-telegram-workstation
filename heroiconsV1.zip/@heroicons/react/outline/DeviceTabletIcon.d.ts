import * as React from 'react';
declare function DeviceTabletIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default DeviceTabletIcon;
