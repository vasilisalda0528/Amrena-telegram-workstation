import * as React from 'react';
declare function BriefcaseIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default BriefcaseIcon;
