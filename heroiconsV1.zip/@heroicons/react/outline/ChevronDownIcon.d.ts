import * as React from 'react';
declare function ChevronDownIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChevronDownIcon;
