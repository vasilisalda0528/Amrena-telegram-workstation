import * as React from 'react';
declare function ChevronRightIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChevronRightIcon;
