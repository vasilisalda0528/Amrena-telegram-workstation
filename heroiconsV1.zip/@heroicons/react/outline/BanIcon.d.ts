import * as React from 'react';
declare function BanIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default BanIcon;
