import * as React from 'react';
declare function ArrowDownIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowDownIcon;
