import * as React from 'react';
declare function StopIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default StopIcon;
