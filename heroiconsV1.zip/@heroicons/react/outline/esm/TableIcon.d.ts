import * as React from 'react';
declare function TableIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default TableIcon;
