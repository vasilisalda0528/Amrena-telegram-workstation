import * as React from 'react';
declare function SortAscendingIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default SortAscendingIcon;
