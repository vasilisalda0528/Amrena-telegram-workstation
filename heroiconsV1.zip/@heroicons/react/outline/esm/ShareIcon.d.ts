import * as React from 'react';
declare function ShareIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ShareIcon;
