import * as React from 'react';
declare function LockClosedIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default LockClosedIcon;
