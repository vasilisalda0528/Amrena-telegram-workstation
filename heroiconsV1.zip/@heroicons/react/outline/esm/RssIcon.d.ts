import * as React from 'react';
declare function RssIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default RssIcon;
