import * as React from 'react';
declare function HeartIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default HeartIcon;
