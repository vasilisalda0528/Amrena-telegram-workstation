import * as React from 'react';
declare function LightningBoltIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default LightningBoltIcon;
