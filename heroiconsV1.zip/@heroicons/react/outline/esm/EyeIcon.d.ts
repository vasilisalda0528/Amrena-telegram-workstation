import * as React from 'react';
declare function EyeIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default EyeIcon;
