import * as React from 'react';
declare function LinkIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default LinkIcon;
