import * as React from 'react';
declare function VolumeOffIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default VolumeOffIcon;
