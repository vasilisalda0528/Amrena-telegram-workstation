import * as React from 'react';
declare function ViewGridIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ViewGridIcon;
