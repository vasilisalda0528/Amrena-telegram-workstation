import * as React from 'react';
declare function TrendingUpIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default TrendingUpIcon;
