import * as React from 'react';
declare function TrendingDownIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default TrendingDownIcon;
