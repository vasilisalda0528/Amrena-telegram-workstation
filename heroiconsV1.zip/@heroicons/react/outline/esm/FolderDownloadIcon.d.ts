import * as React from 'react';
declare function FolderDownloadIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default FolderDownloadIcon;
