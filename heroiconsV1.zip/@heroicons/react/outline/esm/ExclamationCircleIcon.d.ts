import * as React from 'react';
declare function ExclamationCircleIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ExclamationCircleIcon;
