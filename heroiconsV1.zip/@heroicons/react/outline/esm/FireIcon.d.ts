import * as React from 'react';
declare function FireIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default FireIcon;
