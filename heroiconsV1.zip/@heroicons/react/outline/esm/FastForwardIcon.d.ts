import * as React from 'react';
declare function FastForwardIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default FastForwardIcon;
