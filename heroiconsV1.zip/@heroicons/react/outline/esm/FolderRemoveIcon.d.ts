import * as React from 'react';
declare function FolderRemoveIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default FolderRemoveIcon;
