import * as React from 'react';
declare function ShieldExclamationIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ShieldExclamationIcon;
