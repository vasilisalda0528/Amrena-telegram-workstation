import * as React from 'react';
declare function WifiIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default WifiIcon;
