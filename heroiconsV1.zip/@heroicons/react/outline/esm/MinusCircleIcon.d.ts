import * as React from 'react';
declare function MinusCircleIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MinusCircleIcon;
