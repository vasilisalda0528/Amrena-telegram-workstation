import * as React from 'react';
declare function PhoneMissedCallIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PhoneMissedCallIcon;
