import * as React from 'react';
declare function LockOpenIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default LockOpenIcon;
