import * as React from 'react';
declare function PencilAltIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PencilAltIcon;
