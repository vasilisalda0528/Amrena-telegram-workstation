import * as React from 'react';
declare function PaperClipIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PaperClipIcon;
