import * as React from 'react';
declare function TicketIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default TicketIcon;
