import * as React from 'react';
declare function ReplyIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ReplyIcon;
