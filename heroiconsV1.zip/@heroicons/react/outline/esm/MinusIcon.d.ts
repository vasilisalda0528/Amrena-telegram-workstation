import * as React from 'react';
declare function MinusIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MinusIcon;
