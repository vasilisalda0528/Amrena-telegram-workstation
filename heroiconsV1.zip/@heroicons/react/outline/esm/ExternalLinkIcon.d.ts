import * as React from 'react';
declare function ExternalLinkIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ExternalLinkIcon;
