import * as React from 'react';
declare function QrcodeIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default QrcodeIcon;
