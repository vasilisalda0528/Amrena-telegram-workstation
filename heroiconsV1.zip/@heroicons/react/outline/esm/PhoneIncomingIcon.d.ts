import * as React from 'react';
declare function PhoneIncomingIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PhoneIncomingIcon;
