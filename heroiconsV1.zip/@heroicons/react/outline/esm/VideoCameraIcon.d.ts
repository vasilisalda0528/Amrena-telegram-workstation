import * as React from 'react';
declare function VideoCameraIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default VideoCameraIcon;
