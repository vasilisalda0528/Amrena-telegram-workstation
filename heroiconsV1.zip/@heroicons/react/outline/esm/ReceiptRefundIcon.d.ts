import * as React from 'react';
declare function ReceiptRefundIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ReceiptRefundIcon;
