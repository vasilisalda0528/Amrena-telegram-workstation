import * as React from 'react';
declare function TrashIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default TrashIcon;
