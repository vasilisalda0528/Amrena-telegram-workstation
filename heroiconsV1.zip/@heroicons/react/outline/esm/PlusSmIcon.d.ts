import * as React from 'react';
declare function PlusSmIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PlusSmIcon;
