import * as React from 'react';
declare function MoonIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MoonIcon;
