import * as React from 'react';
declare function RefreshIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default RefreshIcon;
