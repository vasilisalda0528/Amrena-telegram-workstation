import * as React from 'react';
declare function MinusSmIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MinusSmIcon;
