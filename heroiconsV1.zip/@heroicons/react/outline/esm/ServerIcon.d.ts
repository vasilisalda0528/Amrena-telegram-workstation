import * as React from 'react';
declare function ServerIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ServerIcon;
