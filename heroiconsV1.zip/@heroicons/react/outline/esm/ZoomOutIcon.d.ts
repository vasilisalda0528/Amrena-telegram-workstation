import * as React from 'react';
declare function ZoomOutIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ZoomOutIcon;
