import * as React from 'react';
declare function MapIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MapIcon;
