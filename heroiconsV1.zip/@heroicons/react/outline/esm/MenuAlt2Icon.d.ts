import * as React from 'react';
declare function MenuAlt2Icon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MenuAlt2Icon;
