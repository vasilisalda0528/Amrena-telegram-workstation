import * as React from 'react';
declare function LibraryIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default LibraryIcon;
