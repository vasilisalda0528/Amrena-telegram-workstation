import * as React from 'react';
declare function FingerPrintIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default FingerPrintIcon;
