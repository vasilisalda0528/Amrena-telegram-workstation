import * as React from 'react';
declare function TerminalIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default TerminalIcon;
