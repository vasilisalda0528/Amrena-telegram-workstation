import * as React from 'react';
declare function MenuAlt4Icon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MenuAlt4Icon;
