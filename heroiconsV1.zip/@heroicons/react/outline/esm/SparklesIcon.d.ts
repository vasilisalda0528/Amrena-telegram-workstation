import * as React from 'react';
declare function SparklesIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default SparklesIcon;
