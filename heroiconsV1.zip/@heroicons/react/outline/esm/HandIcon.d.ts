import * as React from 'react';
declare function HandIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default HandIcon;
