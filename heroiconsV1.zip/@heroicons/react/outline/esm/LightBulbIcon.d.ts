import * as React from 'react';
declare function LightBulbIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default LightBulbIcon;
