import * as React from 'react';
declare function ViewGridAddIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ViewGridAddIcon;
