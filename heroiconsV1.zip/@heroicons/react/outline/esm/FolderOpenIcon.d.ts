import * as React from 'react';
declare function FolderOpenIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default FolderOpenIcon;
