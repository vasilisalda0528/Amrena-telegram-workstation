import * as React from 'react';
declare function GlobeAltIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default GlobeAltIcon;
