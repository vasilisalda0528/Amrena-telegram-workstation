import * as React from 'react';
declare function SearchCircleIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default SearchCircleIcon;
