import * as React from 'react';
declare function SwitchVerticalIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default SwitchVerticalIcon;
