import * as React from 'react';
declare function ViewListIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ViewListIcon;
