import * as React from 'react';
declare function ScaleIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ScaleIcon;
