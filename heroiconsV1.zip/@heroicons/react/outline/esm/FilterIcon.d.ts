import * as React from 'react';
declare function FilterIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default FilterIcon;
