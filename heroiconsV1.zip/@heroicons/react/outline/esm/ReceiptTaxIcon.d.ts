import * as React from 'react';
declare function ReceiptTaxIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ReceiptTaxIcon;
