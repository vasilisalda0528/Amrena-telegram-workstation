import * as React from 'react';
declare function MenuIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MenuIcon;
