import * as React from 'react';
declare function IdentificationIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default IdentificationIcon;
