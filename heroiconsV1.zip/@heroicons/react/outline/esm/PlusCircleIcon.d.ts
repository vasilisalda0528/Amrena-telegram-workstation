import * as React from 'react';
declare function PlusCircleIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PlusCircleIcon;
