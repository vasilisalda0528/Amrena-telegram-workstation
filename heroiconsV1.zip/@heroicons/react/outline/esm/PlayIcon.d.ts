import * as React from 'react';
declare function PlayIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PlayIcon;
