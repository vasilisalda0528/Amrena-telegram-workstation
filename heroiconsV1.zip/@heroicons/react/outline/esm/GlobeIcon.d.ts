import * as React from 'react';
declare function GlobeIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default GlobeIcon;
