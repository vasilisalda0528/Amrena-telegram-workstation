import * as React from 'react';
declare function PresentationChartBarIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PresentationChartBarIcon;
