import * as React from 'react';
declare function RewindIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default RewindIcon;
