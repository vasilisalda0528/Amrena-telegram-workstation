import * as React from 'react';
declare function PlusIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PlusIcon;
