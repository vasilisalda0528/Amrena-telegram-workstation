import * as React from 'react';
declare function LocationMarkerIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default LocationMarkerIcon;
