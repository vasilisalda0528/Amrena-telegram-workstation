import * as React from 'react';
declare function SwitchHorizontalIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default SwitchHorizontalIcon;
