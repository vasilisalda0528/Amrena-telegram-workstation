import * as React from 'react';
declare function VolumeUpIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default VolumeUpIcon;
