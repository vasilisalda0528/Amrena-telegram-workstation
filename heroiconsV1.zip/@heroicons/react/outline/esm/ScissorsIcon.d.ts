import * as React from 'react';
declare function ScissorsIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ScissorsIcon;
