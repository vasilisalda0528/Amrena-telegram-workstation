import * as React from 'react';
declare function HashtagIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default HashtagIcon;
