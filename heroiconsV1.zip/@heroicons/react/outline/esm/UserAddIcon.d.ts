import * as React from 'react';
declare function UserAddIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default UserAddIcon;
