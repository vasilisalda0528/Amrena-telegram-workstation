import * as React from 'react';
declare function MenuAlt3Icon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MenuAlt3Icon;
