import * as React from 'react';
declare function StarIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default StarIcon;
