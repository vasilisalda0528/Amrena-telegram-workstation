import * as React from 'react';
declare function UserGroupIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default UserGroupIcon;
