import * as React from 'react';
declare function XIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default XIcon;
