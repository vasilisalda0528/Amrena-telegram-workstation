import * as React from 'react';
declare function PuzzleIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PuzzleIcon;
