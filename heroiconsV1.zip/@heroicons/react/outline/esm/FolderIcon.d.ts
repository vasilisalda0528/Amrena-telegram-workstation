import * as React from 'react';
declare function FolderIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default FolderIcon;
