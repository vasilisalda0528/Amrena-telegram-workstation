import * as React from 'react';
declare function PhotographIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PhotographIcon;
