import * as React from 'react';
declare function ThumbUpIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ThumbUpIcon;
