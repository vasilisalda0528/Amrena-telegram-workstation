import * as React from 'react';
declare function MicrophoneIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MicrophoneIcon;
