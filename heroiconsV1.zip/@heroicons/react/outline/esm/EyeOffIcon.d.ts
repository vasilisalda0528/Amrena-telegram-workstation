import * as React from 'react';
declare function EyeOffIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default EyeOffIcon;
