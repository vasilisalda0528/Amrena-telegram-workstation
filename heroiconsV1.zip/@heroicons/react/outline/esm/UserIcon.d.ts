import * as React from 'react';
declare function UserIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default UserIcon;
