import * as React from 'react';
declare function SaveIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default SaveIcon;
