import * as React from 'react';
declare function ShieldCheckIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ShieldCheckIcon;
