import * as React from 'react';
declare function PhoneIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PhoneIcon;
