import * as React from 'react';
declare function InboxIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default InboxIcon;
