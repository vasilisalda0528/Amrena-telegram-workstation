import * as React from 'react';
declare function OfficeBuildingIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default OfficeBuildingIcon;
