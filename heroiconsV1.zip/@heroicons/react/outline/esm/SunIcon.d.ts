import * as React from 'react';
declare function SunIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default SunIcon;
