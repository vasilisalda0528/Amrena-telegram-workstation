import * as React from 'react';
declare function MailOpenIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MailOpenIcon;
