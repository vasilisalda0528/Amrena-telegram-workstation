import * as React from 'react';
declare function SortDescendingIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default SortDescendingIcon;
