import * as React from 'react';
declare function PresentationChartLineIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default PresentationChartLineIcon;
