import * as React from 'react';
declare function UserCircleIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default UserCircleIcon;
