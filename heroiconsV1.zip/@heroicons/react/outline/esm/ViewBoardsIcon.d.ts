import * as React from 'react';
declare function ViewBoardsIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ViewBoardsIcon;
