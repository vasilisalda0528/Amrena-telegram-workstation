import * as React from 'react';
declare function MenuAlt1Icon(props: React.ComponentProps<'svg'>): JSX.Element;
export default MenuAlt1Icon;
