import * as React from 'react';
declare function BackspaceIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default BackspaceIcon;
