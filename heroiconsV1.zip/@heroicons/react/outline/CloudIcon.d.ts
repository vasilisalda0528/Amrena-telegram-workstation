import * as React from 'react';
declare function CloudIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CloudIcon;
