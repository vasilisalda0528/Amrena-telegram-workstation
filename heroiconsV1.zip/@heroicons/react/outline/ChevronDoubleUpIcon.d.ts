import * as React from 'react';
declare function ChevronDoubleUpIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChevronDoubleUpIcon;
