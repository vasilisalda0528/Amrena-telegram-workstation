import * as React from 'react';
declare function CollectionIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CollectionIcon;
