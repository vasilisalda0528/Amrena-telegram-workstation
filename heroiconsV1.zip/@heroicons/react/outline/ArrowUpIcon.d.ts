import * as React from 'react';
declare function ArrowUpIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ArrowUpIcon;
