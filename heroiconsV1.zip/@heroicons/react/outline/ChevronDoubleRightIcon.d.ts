import * as React from 'react';
declare function ChevronDoubleRightIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChevronDoubleRightIcon;
