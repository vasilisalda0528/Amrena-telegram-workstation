import * as React from 'react';
declare function AcademicCapIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default AcademicCapIcon;
