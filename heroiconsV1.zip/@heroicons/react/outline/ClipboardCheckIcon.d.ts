import * as React from 'react';
declare function ClipboardCheckIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ClipboardCheckIcon;
