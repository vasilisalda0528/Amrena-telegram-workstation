import * as React from 'react';
declare function ChartBarIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChartBarIcon;
