import * as React from 'react';
declare function ChipIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChipIcon;
