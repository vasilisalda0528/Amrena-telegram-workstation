import * as React from 'react';
declare function ClipboardListIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ClipboardListIcon;
