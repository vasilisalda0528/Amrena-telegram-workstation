import * as React from 'react';
declare function ClipboardCopyIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ClipboardCopyIcon;
