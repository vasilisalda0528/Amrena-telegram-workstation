import * as React from 'react';
declare function ChartSquareBarIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default ChartSquareBarIcon;
