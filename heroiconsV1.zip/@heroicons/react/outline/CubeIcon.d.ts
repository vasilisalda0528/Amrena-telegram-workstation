import * as React from 'react';
declare function CubeIcon(props: React.ComponentProps<'svg'>): JSX.Element;
export default CubeIcon;
